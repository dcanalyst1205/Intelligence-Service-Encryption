public class Encryption{
    private String s1;
    private String s2;
    private String s3;
    private String s4;
    private String s5;
    private String s6;
    private String s7;
    private String s8;
    private String s9;

    /**
     * Constructor for Encryption
     */
    public Encryption(){
        this.s1 = "ABC";
        this.s2 = "DEF";
        this.s3 = "GHI";
        this.s4 = "JKL";
        this.s5 = "MNO";
        this.s6 = "PQR";
        this.s7 = "STU";
        this.s8 = "VWX";
        this.s9 = "YZ ";
    }

    /**
     * This method recursively encrypts the given number by taking in the array, an empty string and an index.
     * After this, it has 3 individual recursive calls for the letters in the first string and adds from there.
     * @param digits
     * @param encrypted
     * @param index
     */
    public void encrypt(String[] digits, String encrypted, int index){
        if(encrypted.length() == digits.length){
            System.out.println(encrypted);
            return;
        }
        String values = digits[index];
        encrypt(digits, encrypted+values.charAt(0), index + 1);
        encrypt(digits, encrypted+values.charAt(1), index + 1);
        encrypt(digits, encrypted+values.charAt(2), index + 1);
    }

    /**
     * This method takes in the number inputted by the user and creates the array with the strings in their respective indices
     * @param number
     * @return
     */
    public String[] creation(String number){
        char[] initialNumber = number.toCharArray();
        String[] digits1 = new String[initialNumber.length];
        for(int i = 0; i < initialNumber.length; i++){
            if(initialNumber[i]=='1'){
                digits1[i] = s1;
            }else if(initialNumber[i]=='2'){
                digits1[i] = s2;
            }else if(initialNumber[i]=='3'){
                digits1[i] = s3;
            }else if(initialNumber[i]=='4'){
                digits1[i] = s4;
            }else if(initialNumber[i]=='5'){
                digits1[i] = s5;
            }else if(initialNumber[i]=='6'){
                digits1[i] = s6;
            }else if(initialNumber[i]=='7'){
                digits1[i] = s7;
            }else if(initialNumber[i]=='8'){
                digits1[i] = s8;
            }else if(initialNumber[i]=='9'){
                digits1[i] = s9;
            }
        }

        return digits1;

    }




}


